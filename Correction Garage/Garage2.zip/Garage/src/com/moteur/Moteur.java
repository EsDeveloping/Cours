package com.moteur;
import java.io.Serializable;

public class Moteur implements Serializable{
	protected String cylindre;
	protected double prix;
	protected TypeMoteur typeMotor;
	
	public Moteur(){}
	
	public Moteur(String cylindre, double prix){
		this.cylindre = cylindre;
		this.prix = prix;
	}
	
	public String toString(){
		return this.cylindre + " " + this.typeMotor;
	}
}
