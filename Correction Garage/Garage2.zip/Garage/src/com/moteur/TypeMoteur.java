package com.moteur;


public enum TypeMoteur {
	DIESEL,
	ESSENCE,
	HYBRIDE,
	ELECTRIQUE;
}
