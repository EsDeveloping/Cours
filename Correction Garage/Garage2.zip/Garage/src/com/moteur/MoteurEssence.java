package com.moteur;
import java.io.Serializable;

public class MoteurEssence extends Moteur implements Serializable {

	public MoteurEssence(String cylindre, double prix){
		super(cylindre, prix);
		this.typeMotor = TypeMoteur.ESSENCE;
	}
}
