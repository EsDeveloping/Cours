package com.option;
import java.io.Serializable;

public class VitreElectrique implements Option, Serializable {
	private double prix = 212.35d;
	
	public double getPrix() {
		return this.prix;
	}
	
	public String description(){
		return "Vitre Electrique (" + this.prix + ")";
	}
}
