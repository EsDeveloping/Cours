package com.option;
import java.io.Serializable;

public class Climatisation implements Option, Serializable{
	private double prix = 347.3d;
	
	public double getPrix() {
		return this.prix;
	}
	
	public String description(){
		return "Climatisation (" + this.prix + ")";
	}
}
