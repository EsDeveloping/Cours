package com.option;

public interface Option {
	public double getPrix();
	public String description();
}
