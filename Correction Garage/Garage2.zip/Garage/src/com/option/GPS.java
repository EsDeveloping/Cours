package com.option;
import java.io.Serializable;

public class GPS implements Option, Serializable {
	private double prix = 113.5d;
	
	public double getPrix() {
		return this.prix;
	}
	
	public String description(){
		return "GPS (" + this.prix + ")";
	}
}
