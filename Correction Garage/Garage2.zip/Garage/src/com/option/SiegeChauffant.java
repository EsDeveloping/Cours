package com.option;
import java.io.Serializable;

public class SiegeChauffant implements Option, Serializable{
	private double prix = 562.9d;
	
	public double getPrix() {
		return this.prix;
	}
	
	public String description(){
		return "Si�ge chauffant (" + this.prix + ")";
	}
}
