package com.option;
import java.io.Serializable;

public class BarreDeToit implements Option, Serializable {
	private double prix = 29.9d;
	
	public double getPrix() {
		return this.prix;
	}
	
	public String description(){
		return "Barre de Toit (" + this.prix + ")";
	}
}
