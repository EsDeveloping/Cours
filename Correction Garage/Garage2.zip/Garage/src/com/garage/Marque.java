package com.garage;

public enum Marque {
	Lagouna("RENO"),
	A300B("PIGEOT"),
	D4("TROEN");
	
	private String model;
	
	Marque(String model){
		this.model = model;
	}
	
	public String getMarque(){
		return model;
	}
}
