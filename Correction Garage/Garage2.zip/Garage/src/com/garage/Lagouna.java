package com.garage;


public class Lagouna extends Vehicule {
	
	public Lagouna(){
		this.nomMarque = Marque.Lagouna;
		this.prix = 23123.0d;
	}
	
	
}
