package com.garage;
import java.util.ArrayList;
import java.util.List;
import com.option.*;
import com.moteur.*;
import java.io.Serializable;

public abstract class Vehicule implements Serializable{
	protected double prix;
	protected String nom;
	protected Marque nomMarque;
	protected List<Option> options = new ArrayList<Option>();
	private Moteur motor = new Moteur();
	
	public Vehicule(){}
	
	public void addOption(Option  option){
		// ajoute une option
		this.options.add(option);
	}
	
	public void setMoteur(Moteur motorisation){
		// ajoute un moteur
		this.motor = motorisation;
	}
	
	private String getOption(){
		// fait la liste des options
		String strOption = "";
		for (Option o : options){
			strOption =  o.description() + ", " + strOption;
		}
		return strOption;
	}
	
	private String getMarque(){
		// r�cup�re la marque dans l'�num�ration
		return this.nomMarque.getMarque() + " : " + this.nomMarque;
	}
	
	private double getPrix(){
		// calcule le prix total (v�hicule + options)
		double prixTotal = prix;
		for (Option o : options){
			prixTotal = prixTotal + o.getPrix();
		}
		return prixTotal;
	}
	
	public String toString(){
		// description du v�hicule
		return "+ Voiture " + this.getMarque()  
					+ " Moteur " + this.motor.toString() + " (" + this.prix + "�) ["
					+ this.getOption() + "] d'une valeur total de " + this.getPrix() + "�";
	}
}
