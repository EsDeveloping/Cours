package com.garage;


public class D4 extends Vehicule {
	public D4(){
		this.nomMarque = Marque.D4;
		this.prix = 25147.0d;
	}
}
