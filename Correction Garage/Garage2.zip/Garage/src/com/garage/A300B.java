package com.garage;


public class A300B extends Vehicule {
	public A300B(){
		this.nomMarque = Marque.A300B;
		this.prix = 28457.0d;
	}
}
