package com.sdz.garage.app;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import com.sdz.garage.option.*;


public class Garage implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2011439696511340796L;
	private List<Vehicule> voitures;
	
	public Garage() {
		if (this.voitures == null) { 
			this.voitures = new LinkedList<>();
			System.out.println("*************************** \n*  Garage OpenClassRooms  *\n***************************");
		}
	}


	public String toString() {
		String liste = "";
		ListIterator<Vehicule> li = voitures.listIterator();

		while(li.hasNext()) {
			Vehicule v = li.next();
			liste += " + Voiture : " + v.getNomMarque() + " : " + v.getNom() + " " + v.getMoteur().toString() + " (" + v.getPrix() + "�) [";
			
			Iterator<Option> l = v.getOptions().iterator();
			while (l.hasNext()) {
				Option o = l.next();
				liste += o.getNom() + " (" + o.getPrix() + "�)";
				if (l.hasNext()) liste += ", ";
			}
			liste += "] d'une valeur totale de " + (v.getPrix() + v.getPrixOptions()) + "�. \n";
			
		}
		return liste;
	}


	public void addVoiture(Vehicule v) {
		if (v == null) return;
		this.voitures.add(v);
	}




}
