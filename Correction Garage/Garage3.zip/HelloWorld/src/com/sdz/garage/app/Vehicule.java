package com.sdz.garage.app;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import com.sdz.garage.option.*;
import com.sdz.garage.vehicule.*;
import com.sdz.garage.moteur.*;


public class Vehicule implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3680288774798262858L;
	protected double prix;
	protected String nom;
	protected List<Option> options;
	protected Marque nomMarque;
	protected Moteur moteur;
	protected double prixOptions;
	
	
	public Vehicule() {
		this.prix = 0;
		this.prixOptions = 0;
		this.options = new LinkedList<Option>();
	}


	public String getNom() {
		return this.nom;
	}

	
	public Marque getNomMarque() {
		return nomMarque;
	}
	
	
	public Moteur getMoteur(){
		return this.moteur;
	}
	
	
	public void setMoteur(Moteur moteur) {
		this.moteur = moteur;
		this.prix += moteur.getPrix();
		
	}
	
	
	public void addOption(Option opt) {
		this.options.add(opt);
		this.prixOptions += opt.getPrix();
	}

	
	public List<Option> getOptions() {
		return options;
	}

	
	public double getPrix() {
		return prix;
	}
	
	
	public double getPrixOptions() {
		return prixOptions;
	}


	public String toString() {
		String v = "";
		v += "Nom : " + this.nom + " \n";
		v += "Prix : " + this.prix + "� \n";
		v += "Marque : " + this.nomMarque + " \n";
		
		return v;
	}


}
