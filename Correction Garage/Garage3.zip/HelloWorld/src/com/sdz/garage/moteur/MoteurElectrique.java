package com.sdz.garage.moteur;


public class MoteurElectrique extends Moteur {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 6770195381669412893L;

	public MoteurElectrique(String cylindre, double prix) {
		this.type = TypeMoteur.ELECT;
		this.cylindre = cylindre;
		this.prix = prix;
	}
}
