package com.sdz.garage.moteur;

public enum TypeMoteur {
	
	DIESEL("Diesel"),
	ESSENCE("Essence"),
	HYBRID("Hybride"),
	ELECT("Electrique");
	
	private TypeMoteur(String typeMoteur) {
		// TODO Auto-generated constructor stub
	}

}
