package com.sdz.garage.moteur;

public class MoteurDiesel extends Moteur {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 2149326808315266202L;

	public MoteurDiesel(String cylindre, double prix) {
		this.type = TypeMoteur.DIESEL;
		this.cylindre = cylindre;
		this.prix = prix;
	}
}
