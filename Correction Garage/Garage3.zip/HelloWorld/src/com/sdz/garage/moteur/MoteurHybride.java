package com.sdz.garage.moteur;

public class MoteurHybride extends Moteur {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -4585176180171971642L;

	public MoteurHybride(String cylindre, double prix) {
		this.type = TypeMoteur.HYBRID;
		this.cylindre = cylindre;
		this.prix = prix;
	}
}
