package com.sdz.garage.moteur;

public class MoteurEssence extends Moteur {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -8360444643923508035L;

	public MoteurEssence(String cylindre, double prix) {
		this.type = TypeMoteur.ESSENCE;
		this.cylindre = cylindre;
		this.prix = prix;
	}
}
