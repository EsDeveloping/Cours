package com.sdz.garage.moteur;
import java.io.Serializable;

public abstract class Moteur implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 283992191655195976L;
	protected TypeMoteur type;
	protected String cylindre;
	protected double prix;
	

	public double getPrix() {
		return prix;
	}
	
	public String toString() {
		return "Moteur " + this.type + " " + this.cylindre;
	}

}
