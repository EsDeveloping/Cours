package com.sdz.garage.vehicule;

import com.sdz.garage.app.Vehicule;

public class Lagouna extends Vehicule {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2159633168033554641L;

	public Lagouna() {
		this.nom = "Lagouna";
		this.nomMarque = Marque.RENO;
	}

}
