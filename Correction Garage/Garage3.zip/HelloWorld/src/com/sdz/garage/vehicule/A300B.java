package com.sdz.garage.vehicule;

import com.sdz.garage.app.Vehicule;

public class A300B extends Vehicule {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5465725200942674578L;

	public A300B() {
		this.nom = "A330B";
		this.nomMarque = Marque.PIGEOT;
	}

}
