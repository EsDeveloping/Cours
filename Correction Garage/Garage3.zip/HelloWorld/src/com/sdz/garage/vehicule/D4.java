package com.sdz.garage.vehicule;

import com.sdz.garage.app.Vehicule;

public class D4 extends Vehicule {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 464473270125755556L;

	public D4() {
		this.nom = "D4";
		this.nomMarque = Marque.TROEN;
	}

}
