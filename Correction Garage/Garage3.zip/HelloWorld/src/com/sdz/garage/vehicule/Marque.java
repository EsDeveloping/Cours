package com.sdz.garage.vehicule;

public enum Marque {
	RENO("Renaut"),
	PIGEOT("Peugoet"),
	TROEN("Citroen");
	
	private Marque(String nomMarque) {
		
	}
	
}
