package com.sdz.garage.option;

public interface Option {
	
	public double getPrix();
	
	public String getNom();

}
