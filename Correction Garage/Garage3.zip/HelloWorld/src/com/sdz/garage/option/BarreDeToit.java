package com.sdz.garage.option;
import java.io.Serializable;

public class BarreDeToit implements Option, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3741653540250781101L;

	@Override
	public double getPrix() {
		return 29.9;
	}

	public String getNom() {
		return "Barre de toit";
	}

}
