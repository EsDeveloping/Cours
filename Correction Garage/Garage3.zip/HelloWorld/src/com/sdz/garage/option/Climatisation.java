package com.sdz.garage.option;
import java.io.Serializable;

public class Climatisation implements Option, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8975617874977517560L;

	@Override
	public double getPrix() {
		return 347.3;
	}
	
	public String getNom() {
		return "Climatisation";
	}


}
