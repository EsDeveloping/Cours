package com.sdz.garage.option;
import java.io.Serializable;

public class SiegeChauffant implements Option, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1990109243834130951L;

	@Override
	public double getPrix() {
		return 562.35;
	}
	
	public String getNom() {
		return "Siege chauffant";
	}

}
