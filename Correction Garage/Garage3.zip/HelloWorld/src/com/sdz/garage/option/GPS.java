package com.sdz.garage.option;
import java.io.Serializable;

public class GPS implements Option, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6254088585787754468L;

	@Override
	public double getPrix() {
		return 113.5;
	}

	public String getNom() {
		return "GPS";
	}

}
