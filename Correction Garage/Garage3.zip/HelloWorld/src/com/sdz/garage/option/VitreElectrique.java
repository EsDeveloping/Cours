package com.sdz.garage.option;
import java.io.Serializable;

public class VitreElectrique implements Option, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1094666726947396859L;

	@Override
	public double getPrix() {
		return 212.35;
	}

	public String getNom() {
		return "Vitre electrique";
	}

}
