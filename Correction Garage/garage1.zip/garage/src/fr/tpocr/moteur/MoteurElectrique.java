/**
 * 
 */
package fr.tpocr.moteur;

/**
 * The Class MoteurElectrique.
 *
 * @author steve
 */
public class MoteurElectrique extends Moteur {

	/**
	 * Instantiates a new moteur electrique.
	 *
	 * @param pCylindre the cylindre
	 * @param pPrix the prix
	 */
	public MoteurElectrique(String pCylindre, Double pPrix) {
		super(pCylindre, pPrix);
		this.type = TypeMoteur.ELECTRIQUE;
		
	}

}
