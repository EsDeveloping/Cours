/**
 * 
 */
package fr.tpocr.moteur;

/**
 * The Enum TypeMoteur.
 *
 * @author steve
 */
public enum TypeMoteur {

	/** The diesel. */
	DIESEL,

	/** The essence. */
	ESSENCE,

	/** The hybride. */
	HYBRIDE,

	/** The electrique. */
	ELECTRIQUE;
}
