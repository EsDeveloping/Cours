/**
 * 
 */
package fr.tpocr.moteur;

/**
 * The Class MoteurHybride.
 *
 * @author steve
 */
public class MoteurHybride extends Moteur {

	/**
	 * Instantiates a new moteur hybride.
	 *
	 * @param pCylindre the cylindre
	 * @param pPrix the prix
	 */
	public MoteurHybride(String pCylindre, Double pPrix) {
		super(pCylindre, pPrix);
		this.type = TypeMoteur.HYBRIDE;
		
	}

}
