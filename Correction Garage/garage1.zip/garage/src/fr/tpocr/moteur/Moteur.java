/**
 * 
 */
package fr.tpocr.moteur;

import java.io.Serializable;

/**
 * The Class Moteur.
 *
 * @author steve
 */
public abstract class Moteur implements Serializable{

	/** The type. */
	protected TypeMoteur type;

	/** The cylindre. */
	protected String cylindre;

	/** The prix. */
	protected Double prix;

	/**
	 * Instantiates a new moteur.
	 *
	 * @param pCylindre the cylindre
	 * @param pPrix the prix
	 */
	public Moteur(String pCylindre, Double pPrix) {
		super();
		this.cylindre = pCylindre;
		this.prix = pPrix;
	}

	/* 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Moteur " + this.type + " " + this.cylindre + " (" + this.prix + "€)";
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public TypeMoteur getType() {
		return this.type;
	}

	/**
	 * Sets the type.
	 *
	 * @param pType the new type
	 */
	public void setType(TypeMoteur pType) {
		this.type = pType;
	}

	/**
	 * Gets the cylindre.
	 *
	 * @return the cylindre
	 */
	public String getCylindre() {
		return this.cylindre;
	}

	/**
	 * Sets the cylindre.
	 *
	 * @param pCylindre the new cylindre
	 */
	public void setCylindre(String pCylindre) {
		this.cylindre = pCylindre;
	}

	/**
	 * Gets the prix.
	 *
	 * @return the prix
	 */
	public Double getPrix() {
		return this.prix;
	}

	/**
	 * Sets the prix.
	 *
	 * @param pPrix the new prix
	 */
	public void setPrix(Double pPrix) {
		this.prix = pPrix;
	}

}
