/**
 * 
 */
package fr.tpocr.moteur;

/**
 * The Class MoteurEssence.
 *
 * @author steve
 */
public class MoteurEssence extends Moteur {

	/**
	 * Instantiates a new moteur essence.
	 *
	 * @param pCylindre the cylindre
	 * @param pPrix the prix
	 */
	public MoteurEssence(String pCylindre, Double pPrix) {
		super(pCylindre, pPrix);
		this.type = TypeMoteur.ESSENCE;
		
	}

}
