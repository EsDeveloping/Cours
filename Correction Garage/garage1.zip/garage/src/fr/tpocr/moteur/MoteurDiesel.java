/**
 * 
 */
package fr.tpocr.moteur;

/**
 * The Class MoteurDiesel.
 *
 * @author steve
 */
public class MoteurDiesel extends Moteur {

	/**
	 * Instantiates a new moteur diesel.
	 *
	 * @param pCylindre the cylindre
	 * @param pPrix the prix
	 */
	public MoteurDiesel(String pCylindre, Double pPrix) {
		super(pCylindre, pPrix);
		this.type=TypeMoteur.DIESEL;
		
	}

}
