/**
 * 
 */
package fr.tpocr.option;

import java.io.Serializable;

/**
 * The Class Option.
 *
 * @author steve
 */
public  abstract class Option implements Ioption, Serializable{

	/** The prix. */
	private Double prix;

	/** The nom. */
	private String nom;


	/**
	 * Instantiates a new option.
	 *
	 * @param pNom the nom
	 * @param pPrix the prix
	 */
	public Option(String pNom, Double pPrix) {
		super();
		this.nom = pNom;
		this.prix = pPrix;
	}

	/* 
	 * @see fr.tpocr.option.Ioption#getNom()
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * Sets the nom.
	 *
	 * @param pNom the new nom
	 */
	public void setNom(String pNom) {
		nom = pNom;
	}

	/* 
	 * @see fr.tpocr.option.Ioption#getPrix()
	 */
	public Double getPrix() {
		return this.prix;
	}

	/**
	 * Sets the prix.
	 *
	 * @param pPrix the new prix
	 */
	public void setPrix(Double pPrix) {
		prix = pPrix;
	}

	/* 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return this.nom + " (" + this.prix + "€)";
	}

}
