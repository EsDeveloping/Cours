/**
 * 
 */
package fr.tpocr.option;

/**
 * The Class Climatisation.
 *
 * @author steve
 */
public class Climatisation extends Option {

	public Climatisation() {
		super("Climatisation", 347.3d);
	}

}
