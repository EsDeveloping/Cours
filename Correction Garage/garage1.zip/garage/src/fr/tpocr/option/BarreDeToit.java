/**
 * 
 */
package fr.tpocr.option;


/**
 * The Class BarreDeToit.
 *
 * @author steve
 */
public class BarreDeToit extends Option {

	public BarreDeToit() {
		super("Barre de toit", 29.9d);
	}
}
