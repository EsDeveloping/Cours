/**
 * 
 */
package fr.tpocr.option;


/**
 * The Class SiegeChauffant.
 *
 * @author steve
 */
public class SiegeChauffant extends  Option {

	/**
	 * Instantiates a new siege chauffant.
	 */
	public SiegeChauffant() {
		super("Siège chauffant", 562.9d);

	}

}
