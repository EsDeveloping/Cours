/**
 * 
 */
package fr.tpocr.option;

/**
 * The Interface Ioption.
 *
 * @author steve
 */
public interface Ioption {

	/**
	 * Gets the prix.
	 *
	 * @return the prix
	 */
	public Double getPrix();
	
	/**
	 * Gets the nom.
	 *
	 * @return the nom
	 */
	public String getNom();
}
