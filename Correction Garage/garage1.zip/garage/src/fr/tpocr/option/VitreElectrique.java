/**
 * 
 */
package fr.tpocr.option;

/**
 * The Class VitreElectrique.
 *
 * @author steve
 */
public class VitreElectrique extends Option {

	/**
	 * Instantiates a new vitre electrique.
	 */
	public VitreElectrique() {
		super("Vitre électrique", 212.35d);
	}

}
