/**
 * 
 */
package fr.tpocr.option;

/**
 * The Class GPS.
 *
 * @author steve
 */
public class GPS extends Option {

	public GPS() {
		super("GPS", 113.5d);
	}
	
}
