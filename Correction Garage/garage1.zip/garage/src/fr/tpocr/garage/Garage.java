/**
 *
 */
package fr.tpocr.garage;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import fr.tpocr.vehicule.Vehicule;

/**
 * The Class Garage.
 *
 * @author steve
 */

public class Garage implements Serializable {

	/** The voitures. */
	private List<Vehicule> voitures = new ArrayList<Vehicule>();

	/** The save file. */
	File saveFile = new File("Garage.txt"); //Création d'un fichier de sauvegarde

	/**
	 * Instantiates a new garage.
	 */
	public Garage() {
		super();
		// Test d'existance du fichier de sauvegarde.
		// Si il existe, on parcours son contenu.
		if (saveFile.exists()){
			try {
				ObjectInputStream ois = new ObjectInputStream(
						new BufferedInputStream(
								new FileInputStream(saveFile)));
				this.voitures = (List<Vehicule>) ois.readObject();
				ois.close();
			} catch (IOException vEx) {
				vEx.printStackTrace();
			} catch (ClassNotFoundException vEx) {
				vEx.printStackTrace();
			}
		}
	}

	/**
	 * Adds the voiture.
	 *
	 * @param voit the voit
	 * 
	 * Ajoute une voiture et l'enregistre dans le fichier de sauvegarde
	 */
	public void addVoiture(Vehicule voit) {
		this.voitures.add(voit);
		try {
			ObjectOutputStream oos = new ObjectOutputStream(
					new BufferedOutputStream(
							new FileOutputStream(saveFile)));
			oos.writeObject(voitures);
			oos.close();
		} catch (IOException vEx) {
			vEx.printStackTrace();
		}

	}

	/*
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		if (this.voitures.isEmpty()){ // Si pas de voiture enregistrée, renvoi d'un message d'erreur.
			System.err.println("Aucune voiture sauvegardée !\n");
		}
		String str = "";
		str += "***************************\n";
		str += "*  Garage OpenClassrooms  *\n";
		str += "***************************\n";

		for (Vehicule vVehicule : voitures) {
			str += vVehicule;
		}
		return str;

	}
}