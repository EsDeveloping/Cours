/**
 * 
 */
package fr.tpocr.vehicule;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import fr.tpocr.moteur.Moteur;
import fr.tpocr.option.Ioption;

/**
 * The Class Vehicule.
 *
 * @author steve
 */
public abstract class Vehicule implements Serializable {

	/** The prix. */
	protected Double prix;

	/** The prix total. */
	protected Double prixTotal;

	/** The nom. */
	protected String nom;

	/** The options. */
	public List<Ioption> options = new ArrayList<Ioption>();

	/** The nom marque. */
	protected Marque nomMarque;

	/** The moteur. */
	protected Moteur moteur;

	/** The prix options total. */
	private Double prixOptionsTotal;

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "+ Voiture " + this.nomMarque + " : " + this.getNom() + " " + moteur + " " + options + " d'une valeur totale de " +
				this.getPrixTotal() + " €\n";
	}

	/**
	 * Adds the option.
	 *
	 * @param opt the opt
	 */
	public void addOption(Ioption opt) {
		this.options.add(opt);
	}

	/**
	 * Gets the prix.
	 *
	 * @return the prix
	 */
	public Double getPrix() {
		return this.prix;
	}

	/**
	 * Sets the prix.
	 *
	 * @param pPrix the new prix
	 */
	public void setPrix(Double pPrix) {
		this.prix = pPrix;
	}

	/**
	 * Gets the prix total.
	 *
	 * @return the prixTotal
	 * A chaque création d'une option, son prix est ajouté dans la variable prixOptionsTotal.
	 * Dans la variable prixTotal j'ajoute le prix d'une voiture avec la valeur total des options.
	 */
	public Double getPrixTotal() {
		Double prixOptionsTotal = 0d;
		for (Ioption vIoption : options) {
			prixOptionsTotal += vIoption.getPrix();
		}
		prixTotal = moteur.getPrix() + prixOptionsTotal;
		return this.prixTotal;

	}

	/**
	 * Sets the prix total.
	 *
	 * @param pPrixTotal the prixTotal to set
	 */
	public void setPrixTotal(Double pPrixTotal) {
		this.prixTotal = pPrixTotal;
	}

	/**
	 * Gets the nom.
	 *
	 * @return the nom
	 */
	public String getNom() {
		return this.nom;
	}

	/**
	 * Sets the nom.
	 *
	 * @param pNom the new nom
	 */
	public void setNom(String pNom) {
		this.nom = pNom;
	}

	/**
	 * Gets the options.
	 *
	 * @return the options
	 */
	public List<Ioption> getOptions() {
		return this.options;
	}

	/**
	 * Sets the options.
	 *
	 * @param pOptions the new options
	 */
	public void setOptions(List<Ioption> pOptions) {
		this.options = pOptions;
	}

	/**
	 * Gets the nom marque.
	 *
	 * @return the nom marque
	 */
	public Marque getNomMarque() {
		return this.nomMarque;
	}

	/**
	 * Sets the nom marque.
	 *
	 * @param pNomMarque the new nom marque
	 */
	public void setNomMarque(Marque pNomMarque) {
		this.nomMarque = pNomMarque;
	}

	/**
	 * Sets the moteur.
	 *
	 * @param pMoteur the moteur to set
	 */
	public void setMoteur(Moteur pMoteur) {
		this.moteur = pMoteur;
	}

	/**
	 * Gets the prix options total.
	 *
	 * @return the prixOptionsTotal
	 */
	public Double getPrixOptionsTotal() {
		return prixOptionsTotal;
	}

	/**
	 * Sets the prix options total.
	 *
	 * @param pPrixOptionsTotal the prixOptionsTotal to set
	 */
	public void setPrixOptionsTotal(Double pPrixOptionsTotal) {
		this.prixOptionsTotal = pPrixOptionsTotal;
	}




}
