/**
 * 
 */
package fr.tpocr.vehicule;

// TODO: Auto-generated Javadoc
/**
 * The Enum Marque.
 *
 * @author steve
 */
public enum Marque {
	
	/** The reno. */
	RENO,
	
	/** The pigeot. */
	PIGEOT,
	
	/** The troen. */
	TROEN;
}
