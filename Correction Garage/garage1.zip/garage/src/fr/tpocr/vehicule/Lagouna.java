/**
 * 
 */
package fr.tpocr.vehicule;

// TODO: Auto-generated Javadoc
/**
 * The Class Lagouna.
 *
 * @author steve
 */
public class Lagouna extends Vehicule {

	/**
	 * Instantiates a new lagouna.
	 */
	public Lagouna() {
		this.nom = "Lagouna";
		this.nomMarque = Marque.RENO;
	}

}
