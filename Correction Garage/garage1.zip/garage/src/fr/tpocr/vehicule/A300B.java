/**
 * 
 */
package fr.tpocr.vehicule;

// TODO: Auto-generated Javadoc
/**
 * The Class A300B.
 *
 * @author steve
 */
public class A300B extends Vehicule {

	/**
	 * Instantiates a new a300b.
	 */
	public A300B() {
		this.nom = "A300B";
		this.nomMarque = Marque.PIGEOT;
	}

}
