/**
 * 
 */
package fr.tpocr.vehicule;

// TODO: Auto-generated Javadoc
/**
 * The Class D4.
 *
 * @author steve
 */
public class D4 extends Vehicule {

	/**
	 * Instantiates a new d4.
	 */
	public D4() {
		this.nom = "D4";
		this.nomMarque = Marque.TROEN;
	}

}
